<?php
/*
 * Copyright(c) 2012 GMO Payment Gateway, Inc. All rights reserved.
 * http://www.gmo-pg.com/
 */

// {{{ requires
require_once(MDL_PG_MULPAY_PAGE_HELPER_PATH . 'LC_PageHelper_Mdl_PG_MULPAY_Base.php');

/**
 * 決済モジュール 決済画面ヘルパー：ベース
 */
class LC_PageHelper_MDL_PG_MULPAY_Base_Ex extends LC_PageHelper_MDL_PG_MULPAY_Base {
    /**
     * コンストラクタ
     *
     * @return void
     */
    function __construct() {
        parent::__construct();
    }


}
?>