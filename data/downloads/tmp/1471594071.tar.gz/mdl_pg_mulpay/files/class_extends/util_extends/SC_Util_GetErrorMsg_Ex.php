<?php
/**
 *
 * @copyright 2012 GMO Payment Gateway, Inc. All Rights Reserved.
 * @link http://www.gmo-pg.com/
 *
 */


require_once(MODULE_REALDIR . 'mdl_pg_mulpay/inc/include.php');
require_once(MDL_PG_MULPAY_CLASS_PATH . 'util/SC_Util_GetErrorMsg.php');

/**
 * GetErrorMsg class
 */
class SC_Util_GetErrorMsg_Ex extends SC_Util_GetErrorMsg {

}
