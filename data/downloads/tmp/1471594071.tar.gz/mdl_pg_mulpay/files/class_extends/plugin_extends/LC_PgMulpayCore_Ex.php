<?php
/*
 * Copyright(c) 2012 GMO Payment Gateway, Inc. All rights reserved.
 * http://www.gmo-pg.com/
 */

require_once(MDL_PG_MULPAY_CLASS_PATH . 'plugin/LC_PgMulpayCore.php');

/**
 *
 */
class LC_PgMulpayCore_Ex extends LC_PgMulpayCore {


}
